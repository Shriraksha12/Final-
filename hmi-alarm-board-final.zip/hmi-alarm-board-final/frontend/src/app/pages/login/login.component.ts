import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-root">

      <!-- Animated grid background -->
      <div class="grid-bg">
        <div class="grid-lines"></div>
        <div class="orb orb-1"></div>
        <div class="orb orb-2"></div>
        <div class="orb orb-3"></div>
      </div>

      <!-- Floating status nodes -->
      <div class="node node-1">
        <span class="node-dot"></span>
        <span class="node-label">SYSTEM ONLINE</span>
      </div>
      <div class="node node-2">
        <span class="node-dot warn"></span>
        <span class="node-label">3 ACTIVE ALARMS</span>
      </div>

      <!-- Center panel -->
      <div class="panel-wrap">

        <!-- Left decorative column -->
        <div class="deco-col">
          <div class="deco-title">HMI ALARM BOARD</div>
          <div class="deco-sub">Industrial Monitoring System</div>
          <div class="deco-sep"></div>
          <div class="deco-stats">
            <div class="deco-stat" *ngFor="let s of stats; let i = index"
                 [style.animation-delay]="i * 0.15 + 's'">
              <span class="deco-stat-val">{{ s.val }}</span>
              <span class="deco-stat-lbl">{{ s.lbl }}</span>
            </div>
          </div>
          <div class="scan-line"></div>
        </div>

        <!-- Divider -->
        <div class="panel-divider"></div>

        <!-- Right login form -->
        <div class="form-col">

          <!-- Icon + title -->
          <div class="form-top">
            <div class="hex-icon">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 4L42 14.5V33.5L24 44L6 33.5V14.5L24 4Z"
                      stroke="#58a6ff" stroke-width="1.5" fill="rgba(88,166,255,0.06)"/>
                <path d="M24 14L32 19V29L24 34L16 29V19L24 14Z"
                      fill="rgba(88,166,255,0.15)" stroke="#58a6ff" stroke-width="1"/>
                <circle cx="24" cy="24" r="3" fill="#58a6ff"/>
              </svg>
            </div>
            <h1 class="form-title">SECURE ACCESS</h1>
            <p class="form-sub">Authenticate to enter the control system</p>
          </div>

          <!-- Input fields -->
          <div class="fields">
            <div class="field-wrap" [class.focused]="focusUser" [class.filled]="username">
              <label class="field-label">USERNAME</label>
              <div class="field-inner">
                <svg class="field-icon" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                </svg>
                <input
                  class="field-input"
                  type="text"
                  [(ngModel)]="username"
                  (focus)="focusUser=true"
                  (blur)="focusUser=false"
                  (keyup.enter)="onLogin()"
                  placeholder="Enter username"
                  autocomplete="username"
                />
              </div>
              <div class="field-bar"></div>
            </div>

            <div class="field-wrap" [class.focused]="focusPw" [class.filled]="password">
              <label class="field-label">PASSWORD</label>
              <div class="field-inner">
                <svg class="field-icon" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/>
                </svg>
                <input
                  class="field-input"
                  [type]="showPassword ? 'text' : 'password'"
                  [(ngModel)]="password"
                  (focus)="focusPw=true"
                  (blur)="focusPw=false"
                  (keyup.enter)="onLogin()"
                  placeholder="Enter password"
                  autocomplete="current-password"
                />
                <button class="eye-btn" (click)="showPassword=!showPassword" type="button" tabindex="-1">
                  <svg *ngIf="!showPassword" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                    <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                  </svg>
                  <svg *ngIf="showPassword" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/>
                    <path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/>
                  </svg>
                </button>
              </div>
              <div class="field-bar"></div>
            </div>
          </div>

          <!-- Error -->
          <div class="error-block" *ngIf="errorMsg">
            <svg viewBox="0 0 20 20" fill="currentColor">
              <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
            </svg>
            {{ errorMsg }}
          </div>

          <!-- Login button -->
          <button class="login-btn" (click)="onLogin()" [disabled]="loading" [class.loading]="loading">
            <span class="btn-text" *ngIf="!loading">
              <span>AUTHENTICATE</span>
              <svg viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
              </svg>
            </span>
            <span class="btn-spinner" *ngIf="loading">
              <span class="spinner-ring"></span>
              AUTHENTICATING...
            </span>
          </button>

          <!-- Footer -->
          <div class="form-footer">
            <span class="footer-dot"></span>
            <span>All access attempts are logged and monitored</span>
            <span class="footer-dot"></span>
          </div>

        </div>
      </div>

      <!-- Bottom ticker -->
      <div class="ticker">
        <span class="ticker-label">SYSTEM STATUS</span>
        <div class="ticker-track">
          <span class="ticker-item" *ngFor="let t of tickers">{{ t }}</span>
        </div>
      </div>

    </div>
  `,
  styles: [`
    :host { display: block; }

    .login-root {
      min-height: 100vh;
      background: #050810;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
      font-family: var(--font-sans, 'Inter', sans-serif);
    }

    .grid-bg { position: absolute; inset: 0; pointer-events: none; }
    .grid-lines {
      position: absolute; inset: 0;
      background-image:
        linear-gradient(rgba(88,166,255,0.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(88,166,255,0.04) 1px, transparent 1px);
      background-size: 48px 48px;
    }
    .orb { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.25; }
    .orb-1 {
      width: 500px; height: 500px;
      background: radial-gradient(circle, #1a4a7a, transparent);
      top: -120px; left: -100px;
      animation: orb-drift 12s ease-in-out infinite alternate;
    }
    .orb-2 {
      width: 400px; height: 400px;
      background: radial-gradient(circle, #7c1a1a, transparent);
      bottom: -80px; right: -60px;
      animation: orb-drift 15s ease-in-out infinite alternate-reverse;
    }
    .orb-3 {
      width: 300px; height: 300px;
      background: radial-gradient(circle, #1a4a3a, transparent);
      top: 50%; left: 60%;
      animation: orb-drift 10s ease-in-out infinite alternate;
    }
    @keyframes orb-drift {
      from { transform: translate(0,0) scale(1); }
      to   { transform: translate(30px,20px) scale(1.1); }
    }

    .node {
      position: absolute;
      display: flex; align-items: center; gap: 6px;
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.06);
      border-radius: 20px; padding: 5px 12px;
      font-size: 0.62rem; font-weight: 700; letter-spacing: 0.12em;
      color: rgba(255,255,255,0.35);
    }
    .node-1 { top: 2rem; left: 2rem; }
    .node-2 { top: 2rem; right: 2rem; }
    .node-dot {
      width: 7px; height: 7px; border-radius: 50%;
      background: #22c55e; box-shadow: 0 0 6px #22c55e;
      animation: pulse-dot 2s ease-in-out infinite;
    }
    .node-dot.warn { background: #f59e0b; box-shadow: 0 0 6px #f59e0b; }
    @keyframes pulse-dot { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }

    .panel-wrap {
      display: flex; align-items: stretch;
      background: rgba(255,255,255,0.02);
      border: 1px solid rgba(88,166,255,0.12);
      border-radius: 24px; overflow: hidden;
      box-shadow:
        0 0 0 1px rgba(88,166,255,0.05),
        0 40px 80px rgba(0,0,0,0.7),
        inset 0 1px 0 rgba(255,255,255,0.04);
      width: 860px; max-width: 95vw; min-height: 480px;
      position: relative; z-index: 1;
    }

    .deco-col {
      width: 300px; flex-shrink: 0;
      background: linear-gradient(160deg, rgba(88,166,255,0.06) 0%, rgba(88,166,255,0.01) 100%);
      border-right: 1px solid rgba(88,166,255,0.1);
      padding: 2.5rem 2rem;
      display: flex; flex-direction: column; gap: 0;
      position: relative; overflow: hidden;
    }
    .deco-title {
      font-size: 1rem; font-weight: 800; letter-spacing: 0.2em;
      color: rgba(88,166,255,0.9); text-transform: uppercase;
    }
    .deco-sub {
      font-size: 0.7rem; font-weight: 500; letter-spacing: 0.1em;
      color: rgba(255,255,255,0.25); margin-top: 4px; text-transform: uppercase;
    }
    .deco-sep {
      width: 40px; height: 2px;
      background: linear-gradient(90deg, rgba(88,166,255,0.6), transparent);
      margin: 1.5rem 0;
    }
    .deco-stats { display: flex; flex-direction: column; gap: 1.25rem; }
    .deco-stat {
      display: flex; flex-direction: column; gap: 2px;
      animation: fade-up 0.5s ease both;
    }
    @keyframes fade-up {
      from { opacity: 0; transform: translateY(10px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .deco-stat-val { font-size: 1.6rem; font-weight: 800; color: rgba(255,255,255,0.7); line-height: 1; }
    .deco-stat-lbl { font-size: 0.62rem; font-weight: 600; letter-spacing: 0.12em; color: rgba(255,255,255,0.2); text-transform: uppercase; }
    .scan-line {
      position: absolute; left: 0; right: 0; height: 1px;
      background: linear-gradient(90deg, transparent, rgba(88,166,255,0.4), transparent);
      animation: scan 4s linear infinite; pointer-events: none;
    }
    @keyframes scan { from { top: 0; opacity: 0.8; } 80% { opacity: 0.8; } to { top: 100%; opacity: 0; } }

    .panel-divider {
      width: 1px;
      background: linear-gradient(to bottom, transparent, rgba(88,166,255,0.15) 20%, rgba(88,166,255,0.15) 80%, transparent);
    }

    .form-col {
      flex: 1; padding: 2.5rem 2.5rem;
      display: flex; flex-direction: column; gap: 1.5rem;
      justify-content: center;
    }
    .form-top { display: flex; flex-direction: column; gap: 0.4rem; }
    .hex-icon { width: 52px; height: 52px; margin-bottom: 0.5rem; }
    .hex-icon svg { width: 100%; height: 100%; }
    .form-title {
      font-size: 1.1rem; font-weight: 800; letter-spacing: 0.2em;
      color: rgba(255,255,255,0.85); margin: 0;
    }
    .form-sub { font-size: 0.75rem; color: rgba(255,255,255,0.3); margin: 0; letter-spacing: 0.05em; }

    .fields { display: flex; flex-direction: column; gap: 1.5rem; }
    .field-wrap { display: flex; flex-direction: column; gap: 6px; position: relative; }
    .field-label {
      font-size: 0.6rem; font-weight: 700; letter-spacing: 0.18em;
      color: rgba(255,255,255,0.25); transition: color 0.2s;
    }
    .field-wrap.focused .field-label,
    .field-wrap.filled .field-label { color: rgba(88,166,255,0.7); }
    .field-inner {
      display: flex; align-items: center;
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.07);
      border-radius: 10px; padding: 0 0.75rem;
      transition: border-color 0.2s, background 0.2s;
    }
    .field-wrap.focused .field-inner {
      border-color: rgba(88,166,255,0.35);
      background: rgba(88,166,255,0.04);
    }
    .field-icon { width: 16px; height: 16px; color: rgba(255,255,255,0.2); flex-shrink: 0; transition: color 0.2s; }
    .field-wrap.focused .field-icon { color: rgba(88,166,255,0.6); }
    .field-input {
      flex: 1; background: transparent; border: none; outline: none;
      color: rgba(255,255,255,0.85); font-size: 0.9rem;
      padding: 0.7rem 0.5rem; font-family: inherit; letter-spacing: 0.03em;
    }
    .field-input::placeholder { color: rgba(255,255,255,0.15); }
    .eye-btn {
      background: none; border: none; cursor: pointer;
      color: rgba(255,255,255,0.2); padding: 4px;
      display: flex; border-radius: 4px; transition: color 0.2s;
    }
    .eye-btn:hover { color: rgba(255,255,255,0.5); }
    .eye-btn svg { width: 16px; height: 16px; }
    .field-bar {
      height: 1px;
      background: linear-gradient(90deg, rgba(88,166,255,0.5), transparent);
      transform: scaleX(0); transform-origin: left;
      transition: transform 0.3s ease; margin-top: -1px;
    }
    .field-wrap.focused .field-bar { transform: scaleX(1); }

    .error-block {
      display: flex; align-items: center; gap: 0.5rem;
      background: rgba(239,68,68,0.08);
      border: 1px solid rgba(239,68,68,0.25);
      border-radius: 8px; padding: 0.6rem 0.9rem;
      color: #f87171; font-size: 0.82rem;
      animation: shake 0.3s ease;
    }
    .error-block svg { width: 16px; height: 16px; flex-shrink: 0; }
    @keyframes shake {
      0%,100% { transform: translateX(0); }
      25% { transform: translateX(-6px); }
      75% { transform: translateX(6px); }
    }

    .login-btn {
      width: 100%;
      background: linear-gradient(135deg, rgba(88,166,255,0.9) 0%, rgba(56,130,210,0.9) 100%);
      color: #000; border: none; border-radius: 10px; padding: 0.85rem;
      font-size: 0.8rem; font-weight: 800; letter-spacing: 0.15em;
      cursor: pointer; transition: all 0.2s; position: relative; overflow: hidden;
    }
    .login-btn::before {
      content: ''; position: absolute; inset: 0;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
      transform: translateX(-100%); transition: transform 0.5s ease;
    }
    .login-btn:hover:not(:disabled)::before { transform: translateX(100%); }
    .login-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(88,166,255,0.3); }
    .login-btn:active:not(:disabled) { transform: translateY(0); }
    .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .btn-text { display: flex; align-items: center; justify-content: center; gap: 0.6rem; }
    .btn-text svg { width: 16px; height: 16px; }
    .btn-spinner { display: flex; align-items: center; justify-content: center; gap: 0.75rem; }
    .spinner-ring {
      width: 14px; height: 14px;
      border: 2px solid rgba(0,0,0,0.2); border-top-color: #000;
      border-radius: 50%; display: inline-block;
      animation: spin 0.7s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    .form-footer {
      display: flex; align-items: center; justify-content: center; gap: 0.5rem;
      font-size: 0.62rem; letter-spacing: 0.08em; color: rgba(255,255,255,0.15);
    }
    .footer-dot { width: 4px; height: 4px; border-radius: 50%; background: rgba(255,255,255,0.12); }

    .ticker {
      position: fixed; bottom: 0; left: 0; right: 0; height: 28px;
      background: rgba(88,166,255,0.05);
      border-top: 1px solid rgba(88,166,255,0.08);
      display: flex; align-items: center; overflow: hidden; z-index: 10;
    }
    .ticker-label {
      flex-shrink: 0;
      background: rgba(88,166,255,0.15); color: rgba(88,166,255,0.7);
      font-size: 0.55rem; font-weight: 700; letter-spacing: 0.15em;
      padding: 0 12px; height: 100%; display: flex; align-items: center;
      border-right: 1px solid rgba(88,166,255,0.1);
    }
    .ticker-track {
      flex: 1; display: flex; gap: 0;
      animation: ticker-scroll 30s linear infinite; white-space: nowrap;
    }
    .ticker-item {
      font-size: 0.6rem; font-weight: 600; letter-spacing: 0.1em;
      color: rgba(255,255,255,0.2); padding: 0 2.5rem;
      border-right: 1px solid rgba(255,255,255,0.05);
    }
    @keyframes ticker-scroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    @media (max-width: 700px) {
      .deco-col, .panel-divider { display: none; }
      .panel-wrap { width: 95vw; }
      .form-col { padding: 2rem 1.5rem; }
      .node { display: none; }
    }
  `]
})
export class LoginComponent implements OnInit, OnDestroy {
  private auth = inject(AuthService);
  private router = inject(Router);

  username = '';
  password = '';
  errorMsg = '';
  loading = false;
  showPassword = false;
  focusUser = false;
  focusPw = false;

  stats = [
    { val: '24/7', lbl: 'CONTINUOUS MONITORING' },
    { val: '99.9%', lbl: 'SYSTEM UPTIME' },
    { val: 'AES-256', lbl: 'ENCRYPTION STANDARD' },
  ];

  tickers: string[] = [];
  private tickerBase = [
    'SUBSYSTEM A — NOMINAL',
    'SUBSYSTEM B — NOMINAL',
    'NETWORK LATENCY — 2ms',
    'LAST SYNC — JUST NOW',
    'DB HEALTH — GOOD',
    'SCHEDULER — RUNNING',
    'LOG RETENTION — 90 DAYS',
    'BACKUP — COMPLETE',
  ];

  ngOnInit(): void {
    this.tickers = [...this.tickerBase, ...this.tickerBase];
  }

  ngOnDestroy(): void {}

  onLogin(): void {
    this.errorMsg = '';
    if (!this.username.trim() || !this.password.trim()) {
      this.errorMsg = 'Please enter username and password';
      return;
    }
    this.loading = true;
    setTimeout(() => {
      const result = this.auth.login(this.username.trim(), this.password);
      this.loading = false;
      if (result.success) {
        this.router.navigate(['/dashboard']);
      } else {
        this.errorMsg = result.error || 'Access denied — invalid credentials';
      }
    }, 600);
  }
}
