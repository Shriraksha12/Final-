import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Alarm } from '../../models/alarm.model';
import { AckButtonComponent } from '../ack-button/ack-button.component';

@Component({
  selector: 'app-alarm-list',
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule, AckButtonComponent],
  template: `
    <div class="alarm-table-wrapper">
      <!-- Loading -->
      <div class="loading-overlay" *ngIf="loading">
        <div class="spinner"></div>
        <span>Loading alarms...</span>
      </div>

      <!-- Empty State -->
      <div class="empty-state" *ngIf="!loading && alarms.length === 0">
        <div class="empty-icon">✓</div>
        <div class="empty-text">No alarms match the current filters</div>
      </div>

      <!-- Table -->
      <table class="alarm-table" *ngIf="!loading && alarms.length > 0">
        <thead>
          <tr>
            <th>Code</th>
            <th>Message</th>
            <th>Severity</th>
            <th>State</th>
            <th>Acknowledged By</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr
            *ngFor="let alarm of alarms; trackBy: trackById"
            [class]="'row-' + alarm.severity.toLowerCase()"
            [class.row-cleared]="alarm.state === 'CLEARED'"
          >
            <td><span class="alarm-code">{{ alarm.code }}</span></td>
            <td class="alarm-message">{{ alarm.message }}</td>
            <td>
              <span class="severity-badge" [class]="'sev-' + alarm.severity.toLowerCase()">
                {{ alarm.severity }}
              </span>
            </td>
            <td>
              <span class="state-badge" [class]="'state-' + alarm.state.toLowerCase()">
                {{ alarm.state }}
              </span>
            </td>
            <td class="acked-by">
              <span *ngIf="alarm.acknowledgedBy">
                {{ alarm.acknowledgedBy }}
                <small>{{ alarm.acknowledgedAt | date:'HH:mm dd/MM' }}</small>
              </span>
              <span *ngIf="!alarm.acknowledgedBy" class="text-muted">—</span>
            </td>
            <td class="created-at">{{ alarm.createdAt | date:'dd/MM HH:mm:ss' }}</td>
            <td>
              <app-ack-button
                [alarm]="alarm"
                [isAdmin]="isAdmin"
                (acknowledge)="onAcknowledge(alarm, $event)"
                (clear)="onClear(alarm)"
                (delete)="onDelete(alarm)"
                (viewEvents)="viewEvents.emit($event)"
              ></app-ack-button>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- ── Pagination Bar ── -->
      <div class="pagination-bar" *ngIf="!loading && (totalPages > 0 || alarms.length > 0)">

        <!-- Per-page selector -->
        <div class="per-page">
          <span class="per-page-label">Rows per page</span>
          <div class="per-page-btns">
            <button
              *ngFor="let opt of pageSizeOptions"
              class="size-btn"
              [class.active]="currentSize === opt"
              (click)="onSizeChange(opt)"
            >{{ opt }}</button>
          </div>
        </div>

        <!-- Spacer -->
        <div class="pag-spacer"></div>

        <!-- Info -->
        <span class="pag-info" *ngIf="totalElements > 0">
          {{ rangeStart }}–{{ rangeEnd }} of {{ totalElements }}
        </span>

        <!-- Nav buttons -->
        <div class="pag-nav" *ngIf="totalPages > 1">
          <button class="nav-btn" [disabled]="currentPage === 0" (click)="pageChange.emit(0)" title="First page">
            «
          </button>
          <button class="nav-btn" [disabled]="currentPage === 0" (click)="pageChange.emit(currentPage - 1)" title="Previous">
            ‹
          </button>

          <div class="page-numbers">
            <button
              *ngFor="let p of visiblePages"
              class="page-num"
              [class.active]="p === currentPage"
              [class.ellipsis]="p === -1"
              [disabled]="p === -1 || p === currentPage"
              (click)="p !== -1 && pageChange.emit(p)"
            >{{ p === -1 ? '…' : p + 1 }}</button>
          </div>

          <button class="nav-btn" [disabled]="currentPage >= totalPages - 1" (click)="pageChange.emit(currentPage + 1)" title="Next">
            ›
          </button>
          <button class="nav-btn" [disabled]="currentPage >= totalPages - 1" (click)="pageChange.emit(totalPages - 1)" title="Last page">
            »
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .alarm-table-wrapper {
      background: var(--bg-secondary);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      overflow: hidden;
      position: relative;
      min-height: 200px;
    }
    .loading-overlay {
      position: absolute; inset: 0;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 1rem; background: rgba(0,0,0,0.4); z-index: 10; color: var(--text-secondary);
    }
    .spinner {
      width: 32px; height: 32px;
      border: 3px solid var(--border-color); border-top-color: var(--color-accent);
      border-radius: 50%; animation: spin 0.8s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .empty-state {
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      padding: 4rem; gap: 1rem; color: var(--text-muted);
    }
    .empty-icon { font-size: 3rem; color: var(--color-low); }
    .empty-text { font-size: 0.9rem; }
    .alarm-table { width: 100%; border-collapse: collapse; font-size: 0.875rem; }
    .alarm-table thead tr { background: var(--bg-primary); border-bottom: 2px solid var(--border-color); }
    .alarm-table th {
      padding: 0.75rem 1rem; text-align: left;
      font-size: 0.7rem; font-weight: 700; letter-spacing: 0.1em;
      text-transform: uppercase; color: var(--text-muted); white-space: nowrap;
    }
    .alarm-table tbody tr { border-bottom: 1px solid var(--border-color); transition: background 0.15s; }
    .alarm-table tbody tr:hover { background: var(--bg-hover); }
    .alarm-table td { padding: 0.7rem 1rem; vertical-align: middle; }

    .row-critical td:first-child { border-left: 3px solid var(--color-critical); }
    .row-high    td:first-child { border-left: 3px solid var(--color-high); }
    .row-medium  td:first-child { border-left: 3px solid var(--color-medium); }
    .row-low     td:first-child { border-left: 3px solid var(--color-low); }
    .row-cleared { opacity: 0.55; }

    .alarm-code { font-family: monospace; font-weight: 600; font-size: 0.8rem; }
    .alarm-message { max-width: 280px; }
    .created-at, .acked-by { white-space: nowrap; color: var(--text-secondary); font-size: 0.8rem; }
    .acked-by small { display: block; color: var(--text-muted); font-size: 0.7rem; }
    .text-muted { color: var(--text-muted); }

    .severity-badge {
      display: inline-block; padding: 2px 8px; border-radius: 4px;
      font-size: 0.7rem; font-weight: 700; letter-spacing: 0.05em;
    }
    .sev-critical { background: rgba(239,68,68,0.15);  color: var(--color-critical); border: 1px solid var(--color-critical); }
    .sev-high     { background: rgba(249,115,22,0.15); color: var(--color-high);     border: 1px solid var(--color-high); }
    .sev-medium   { background: rgba(245,158,11,0.15); color: var(--color-medium);   border: 1px solid var(--color-medium); }
    .sev-low      { background: rgba(34,197,94,0.15);  color: var(--color-low);      border: 1px solid var(--color-low); }

    .state-badge {
      display: inline-block; padding: 2px 8px; border-radius: 20px;
      font-size: 0.68rem; font-weight: 700;
    }
    .state-active       { background: rgba(239,68,68,0.2);   color: var(--color-critical); }
    .state-acknowledged { background: rgba(245,158,11,0.2);  color: var(--color-medium); }
    .state-cleared      { background: rgba(107,114,128,0.2); color: var(--text-muted); }

    /* ── Pagination Bar ── */
    .pagination-bar {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 0.75rem;
      padding: 0.75rem 1rem;
      border-top: 1px solid var(--border-color);
      background: var(--bg-primary);
    }
    .pag-spacer { flex: 1; }

    /* Per-page */
    .per-page {
      display: flex;
      align-items: center;
      gap: 0.6rem;
    }
    .per-page-label {
      font-size: 0.72rem;
      font-weight: 600;
      color: var(--text-muted);
      letter-spacing: 0.04em;
      white-space: nowrap;
    }
    .per-page-btns {
      display: flex;
      gap: 3px;
    }
    .size-btn {
      background: var(--bg-secondary);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      padding: 3px 9px;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      line-height: 1.4;
    }
    .size-btn:hover { border-color: var(--color-accent); color: var(--color-accent); }
    .size-btn.active {
      background: rgba(88,166,255,0.12);
      border-color: var(--color-accent);
      color: var(--color-accent);
    }

    /* Info */
    .pag-info {
      font-size: 0.75rem;
      color: var(--text-muted);
      white-space: nowrap;
    }

    /* Nav */
    .pag-nav {
      display: flex;
      align-items: center;
      gap: 3px;
    }
    .nav-btn {
      background: var(--bg-secondary);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      width: 30px; height: 30px;
      border-radius: 7px;
      font-size: 0.9rem;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.15s;
      flex-shrink: 0;
    }
    .nav-btn:hover:not(:disabled) { border-color: var(--color-accent); color: var(--color-accent); }
    .nav-btn:disabled { opacity: 0.3; cursor: not-allowed; }

    .page-numbers {
      display: flex;
      gap: 3px;
    }
    .page-num {
      background: var(--bg-secondary);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      min-width: 30px; height: 30px;
      border-radius: 7px;
      font-size: 0.78rem;
      font-weight: 600;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.15s;
      padding: 0 6px;
    }
    .page-num:hover:not(:disabled):not(.active) { border-color: var(--color-accent); color: var(--color-accent); }
    .page-num.active {
      background: var(--color-accent);
      border-color: var(--color-accent);
      color: #000;
      font-weight: 700;
      cursor: default;
    }
    .page-num.ellipsis {
      border-color: transparent;
      background: transparent;
      cursor: default;
      color: var(--text-muted);
    }
    .page-num:disabled:not(.active):not(.ellipsis) { opacity: 0.4; cursor: not-allowed; }
  `]
})
export class AlarmListComponent {
  @Input() alarms: Alarm[] = [];
  @Input() loading = false;
  @Input() currentPage = 0;
  @Input() totalPages = 0;
  @Input() totalElements = 0;
  @Input() isAdmin = false;
  @Input() currentSize = 20;

  @Output() pageChange = new EventEmitter<number>();
  @Output() sizeChange = new EventEmitter<number>();
  @Output() acknowledge = new EventEmitter<{ alarm: Alarm; operatorName: string; note: string }>();
  @Output() clear = new EventEmitter<Alarm>();
  @Output() delete = new EventEmitter<Alarm>();
  @Output() viewEvents = new EventEmitter<number>();

  pageSizeOptions = [10, 20, 50, 100];

  get rangeStart(): number {
    return this.totalElements === 0 ? 0 : this.currentPage * this.currentSize + 1;
  }

  get rangeEnd(): number {
    return Math.min((this.currentPage + 1) * this.currentSize, this.totalElements);
  }

  get visiblePages(): number[] {
    const total = this.totalPages;
    const cur = this.currentPage;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i);

    const pages: number[] = [];
    if (cur <= 3) {
      pages.push(0, 1, 2, 3, 4, -1, total - 1);
    } else if (cur >= total - 4) {
      pages.push(0, -1, total - 5, total - 4, total - 3, total - 2, total - 1);
    } else {
      pages.push(0, -1, cur - 1, cur, cur + 1, -1, total - 1);
    }
    return pages;
  }

  onSizeChange(size: number): void {
    this.sizeChange.emit(size);
  }

  trackById(_: number, alarm: Alarm): number { return alarm.id; }
  onAcknowledge(alarm: Alarm, payload: { operatorName: string; note: string }): void { this.acknowledge.emit({ alarm, ...payload }); }
  onClear(alarm: Alarm): void { this.clear.emit(alarm); }
  onDelete(alarm: Alarm): void { this.delete.emit(alarm); }
}
